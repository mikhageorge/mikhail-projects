package com.team7.eventticketing.user.controller;

import com.team7.eventticketing.user.dto.FavoriteVenueDTO;
import com.team7.eventticketing.user.service.FavoriteVenueService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.team7.eventticketing.user.dto.UserDTO;

import java.util.List;

import com.team7.eventticketing.user.security.OwnershipChecker;
import org.springframework.web.bind.annotation.RequestHeader;

@RestController
@RequestMapping("/api/users/{userId}/venues")
public class FavoriteVenueController {
    private final FavoriteVenueService favoriteVenueService;
    private final OwnershipChecker ownershipChecker;

    public FavoriteVenueController(FavoriteVenueService favoriteVenueService,
                                   OwnershipChecker ownershipChecker) {
        this.favoriteVenueService = favoriteVenueService;
        this.ownershipChecker = ownershipChecker;
    }

    /**
     * Add a favorite venue for a user
     * POST /api/users/{userId}/venues
     */
    @PostMapping
    public ResponseEntity<FavoriteVenueDTO> addFavoriteVenue(
            @PathVariable Long userId,
            @RequestBody FavoriteVenueDTO favoriteVenueDTO,
            @RequestHeader("Authorization") String authHeader) {
        ownershipChecker.requireOwnerOrAdmin(userId, authHeader);
        FavoriteVenueDTO createdVenue = favoriteVenueService.addFavoriteVenue(userId, favoriteVenueDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdVenue);
    }

    /**
     * Get all favorite venues for a user
     * GET /api/users/{userId}/venues
     */
    @GetMapping
    public ResponseEntity<List<FavoriteVenueDTO>> getUserFavoriteVenues(
            @PathVariable Long userId,
            @RequestHeader("Authorization") String authHeader) {
        ownershipChecker.requireOwnerOrAdmin(userId, authHeader);
        List<FavoriteVenueDTO> venues = favoriteVenueService.getUserFavoriteVenues(userId);
        return ResponseEntity.ok(venues);
    }

    /**
     * Get favorite venue by ID
     * GET /api/users/{userId}/venues/{venueId}
     */
    @GetMapping("/{venueId}")
    public ResponseEntity<FavoriteVenueDTO> getFavoriteVenueById(
            @PathVariable Long userId,
            @PathVariable Long venueId,
            @RequestHeader("Authorization") String authHeader) {
        ownershipChecker.requireOwnerOrAdmin(userId, authHeader);
        FavoriteVenueDTO venue = favoriteVenueService.getFavoriteVenueById(venueId);
        return ResponseEntity.ok(venue);
    }

    /**
     * Update favorite venue
     * PUT /api/users/{userId}/venues/{venueId}
     */
    @PutMapping("/{venueId}")
    public ResponseEntity<FavoriteVenueDTO> updateFavoriteVenue(
            @PathVariable Long userId,
            @PathVariable Long venueId,
            @RequestBody FavoriteVenueDTO favoriteVenueDTO,
            @RequestHeader("Authorization") String authHeader) {
        ownershipChecker.requireOwnerOrAdmin(userId, authHeader);
        FavoriteVenueDTO updatedVenue = favoriteVenueService.updateFavoriteVenue(venueId, favoriteVenueDTO);
        return ResponseEntity.ok(updatedVenue);
    }

    /**
     * Delete favorite venue
     * DELETE /api/users/{userId}/venues/{venueId}
     */
    @DeleteMapping("/{venueId}")
    public ResponseEntity<Void> deleteFavoriteVenue(
            @PathVariable Long userId,
            @PathVariable Long venueId,
            @RequestHeader("Authorization") String authHeader) {
        ownershipChecker.requireOwnerOrAdmin(userId, authHeader);
        favoriteVenueService.deleteFavoriteVenue(venueId);
        return ResponseEntity.noContent().build();
    }

    /**
     * Get default favorite venue for a user
     * GET /api/users/{userId}/venues/default
     */
    @GetMapping("/default")
    public ResponseEntity<FavoriteVenueDTO> getDefaultFavoriteVenue(
            @PathVariable Long userId,
            @RequestHeader("Authorization") String authHeader) {
        ownershipChecker.requireOwnerOrAdmin(userId, authHeader);
        FavoriteVenueDTO venue = favoriteVenueService.getDefaultFavoriteVenue(userId);
        return ResponseEntity.ok(venue);
    }

    /**
     * [S1-F7] Set Default Favorite Venue
     * PUT /api/users/{userId}/venues/{venueId}/default
     */
    @PutMapping("/{venueId}/default")
    public ResponseEntity<UserDTO> setDefaultFavoriteVenue(
            @PathVariable Long userId,
            @PathVariable Long venueId,
            @RequestHeader("Authorization") String authHeader) {
        ownershipChecker.requireOwnerOrAdmin(userId, authHeader);
        UserDTO updatedUser = favoriteVenueService.setDefaultFavoriteVenue(userId, venueId);
        return ResponseEntity.ok(updatedUser);
    }
}